package org.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.example.domain.dto.DailyOrderStatsDTO;
import org.example.domain.dto.DeptOrderStatsDTO;
import org.example.domain.po.WorkOrder;

import java.util.List;

@Mapper
public interface WorkOrderMapper extends BaseMapper<WorkOrder> {
    @Select("SELECT id FROM work_order WHERE order_no = #{orderNo}")
    Long selectByOderNo(String orderNo);

    List<DailyOrderStatsDTO> getDailyOrderStatsForJuly();

    List<DeptOrderStatsDTO> getDeptOrderStatsForJuly();

    //Page<WorkOrder> pageQuery(PageQueryDTO pageQueryDTO);
}
