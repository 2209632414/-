package org.example.domain.po;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("work_order")
public class WorkOrder {
    @TableId
    private Long id; // 工单ID
    private String orderNo; // 工单编号（添加/修改不能重复）
    private int orderType; // 工单类型 (0: 交办, 1: 直接答复, 3: 无效工单)
    private String title; // 标题
    private String content; // 内容
    private Integer handleDeptId; // 处理部门ID，可以为空
    private LocalDateTime createTime; // 创建时间
    private LocalDateTime fenpaiTime; // 分派时间，可以为空
    private int isOverdue; // 是否超期 (0: 否, 1: 是)

}
