package org.example.domain.dto;

import lombok.Data;

@Data
public class FenpaiDTO {
    private Long orderId;
    private Long handleDeptId;
    private String handleDeptName;
}
