package org.example.domain.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@ApiModel(description = "表单实体")
public class WorkOrderDTO {
    private Long id; // 工单ID
    @NotNull
    private String orderNo; // 工单编号(必须)

    private int orderType = 0; // 工单类型 (0: 交办, 1: 直接答复, 3: 无效工单, 默认 0)
    @NotNull
    private String title; // 标题（必须）
    @NotNull
    private String content; // 内容（必须）
    private Integer handleDeptId; // 处理部门ID，可以为空
    private LocalDateTime createTime; // 创建时间（必须）
    private LocalDateTime fenpaiTime; // 分派时间，可以为空

    private int isOverdue = 0; // 是否超期 (0: 否, 1: 是 , 默认 0)

}
