package org.example.domain.dto;

import lombok.Data;

@Data
public class DeptOrderStatsDTO {
    private Long handleDeptId;
    private String handleDeptName;
    private Integer totalOrders;
    private Integer overdueOrders;
    private Double overdueRate;
}
