package org.example.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.domain.dto.*;
import org.example.domain.po.WorkOrder;
import org.example.domain.result.PageResult;
import org.example.domain.result.Result;
import org.example.service.WorkOrderService;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/order")
@Slf4j
@Api("测试接口")
public class WorkOderController {

    private final WorkOrderService workOrderService;

    @PostMapping("/save")
    @ApiOperation("添加数据")
    public Result save(@Valid @RequestBody WorkOrderDTO workOrderDTO){
        log.info("添加工单数据");
        workOrderService.save(workOrderDTO);
        return Result.success();
    }

    @PostMapping("/delete")
    @ApiOperation("根据id删除数据")
    public Result delete(@RequestParam List<Long> ids){
        log.info("删除工单数据");
        workOrderService.removeByIds(ids);
        return Result.success();
    }

    @PostMapping("/update")
    @ApiOperation("修改数据")
    public Result<WorkOrder> update(@RequestBody WorkOrderDTO workOrderDTO){
        log.info("修改工单数据");
        workOrderService.update(workOrderDTO);
        return Result.success();
    }

    @PostMapping("/search")
    @ApiOperation("分页查询")
    public Result<PageResult> search(@RequestBody PageQueryDTO pageQueryDTO){
        log.info("分页查询工单数据");
        //分页查询
        Page<WorkOrder> p = workOrderService.queryPage(pageQueryDTO);
        PageResult pageResult = new PageResult(p.getTotal(),p.getRecords());
        return Result.success(pageResult);
    }

    @PostMapping("/fenpai")
    @ApiOperation("分派工单")
    public Result fenpai(@RequestBody FenpaiDTO fenpaiDTO){
        workOrderService.fenpai(fenpaiDTO);
        return Result.success();
    }

    @GetMapping("/daily-stats")
    @ApiOperation("查询7月每天的工单总量和超期率")
    public Result<List<DailyOrderStatsDTO>> getDailyOrderStatsForJuly() {
        List<DailyOrderStatsDTO> stats = workOrderService.getDailyOrderStatsForJuly();
        return Result.success(stats);
    }

    @GetMapping("/dept-stats")
    @ApiOperation("查询7月每个部门的工单总量和超期率")
    public Result<List<DeptOrderStatsDTO>> getDeptOrderStatsForJuly() {
        List<DeptOrderStatsDTO> stats = workOrderService.getDeptOrderStatsForJuly();
        return Result.success(stats);
    }
}
