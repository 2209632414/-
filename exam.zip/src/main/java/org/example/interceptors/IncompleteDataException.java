package org.example.interceptors;

public class IncompleteDataException extends RuntimeException {
    public IncompleteDataException(String message) {
        super(message);
    }
}
