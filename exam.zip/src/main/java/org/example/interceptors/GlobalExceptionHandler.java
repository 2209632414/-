package org.example.interceptors;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.http.ResponseEntity;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IncompleteDataException.class)
    public ResponseEntity<String> handleIncompleteDataException(IncompleteDataException ex) {
        return ResponseEntity.badRequest().body(ex.getMessage());
    }
}
