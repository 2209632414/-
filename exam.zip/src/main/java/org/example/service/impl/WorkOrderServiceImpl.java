package org.example.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.example.domain.dto.*;
import org.example.domain.po.Department;
import org.example.domain.po.WorkOrder;
import org.example.interceptors.IncompleteDataException;
import org.example.mapper.DepartmentMapper;
import org.example.mapper.WorkOrderMapper;
import org.example.service.WorkOrderService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WorkOrderServiceImpl extends ServiceImpl<WorkOrderMapper, WorkOrder> implements WorkOrderService{

    private final WorkOrderMapper workOrderMapper;

    private final DepartmentMapper departmentMapper;

    /**
     * 添加工单
     * @param workOrderDTO
     */
    @Override
    @Transactional
    public void save(WorkOrderDTO workOrderDTO) {
        //1.将从前端传入的DTO转化为实体类
        WorkOrder workOrder = new WorkOrder();
        BeanUtils.copyProperties(workOrderDTO,workOrder);
        if (workOrder.getOrderNo().isEmpty() || workOrder.getTitle().isEmpty() || workOrder.getContent().isEmpty()) {
            throw new IncompleteDataException("数据不完整，请检查工单编号、标题和内容是否填写");
        }
        //2.判断orderNo是否存在
        Long id = workOrderMapper.selectByOderNo(workOrder.getOrderNo());
        if (id != null){
            throw new IncompleteDataException("工单编号已存在");
        }
        workOrder.setCreateTime(LocalDateTime.now());
        workOrderMapper.insert(workOrder);
    }

    /**
     * 修改工单
     * @param workOrderDTO
     */
    @Override
    @Transactional
    public void update(WorkOrderDTO workOrderDTO) {
        //1.将从前端传入的DTO转化为实体类
        WorkOrder workOrder = new WorkOrder();
        BeanUtils.copyProperties(workOrderDTO,workOrder);
        if (workOrderMapper.selectById(workOrder.getId()) == null){
            throw new IncompleteDataException("该工单不存在");
        }
        //判断修改后的工单是否重复
        if (workOrderMapper.selectByOderNo(workOrder.getOrderNo()) != workOrder.getId()){
            throw new IncompleteDataException("工单号重复");
        }
        QueryWrapper<WorkOrder> queryWrapper = new QueryWrapper<WorkOrder>().eq("id",workOrder.getId());
        workOrderMapper.update(workOrder,queryWrapper);
    }

    /**
     * 分页查询工单
     *
     * @param pageQueryDTO
     * @return
     */
    @Override
    public Page<WorkOrder> queryPage(PageQueryDTO pageQueryDTO) {
        //获取前端传入的分页条件
        Page<WorkOrder> page = Page.of(pageQueryDTO.getPage(), pageQueryDTO.getPageSize());
        //排序条件
        //page.addOrder(new OrderItem("creat_time", true));
        //构建查询条件根据分类菜品名进行模糊查询
        return lambdaQuery()
                .page(page);
    }

    /**
     * 分派工单
     * @param fenpaiDTO
     */
    @Override
    @Transactional
    public void fenpai(FenpaiDTO fenpaiDTO) {
        // 1. 验证处理部门 ID 是否有效
        Department dept = departmentMapper.selectById(fenpaiDTO.getHandleDeptId());
        if (dept == null) {
            throw new IncompleteDataException("处理部门不存在");
        }
        // 2. 更新工单信息
        WorkOrder workOrder = workOrderMapper.selectById(fenpaiDTO.getOrderId());
        if (workOrder == null) {
            throw new IncompleteDataException("工单不存在");
        }
        workOrder.setHandleDeptId(fenpaiDTO.getHandleDeptId().intValue());
        workOrder.setFenpaiTime(LocalDateTime.now()); // 设置分派时间

        workOrderMapper.updateById(workOrder);
    }

    /**
     *  查询 7 月每天的工单总量和超期率
     * @return
     */
    @Override
    public List<DailyOrderStatsDTO> getDailyOrderStatsForJuly() {
        return workOrderMapper.getDailyOrderStatsForJuly();
    }

    /**
     * 查询 7 月每个部门的工单总量和超期率
     * @return
     */
    @Override
    public List<DeptOrderStatsDTO> getDeptOrderStatsForJuly() {
        return workOrderMapper.getDeptOrderStatsForJuly();
    }



}
