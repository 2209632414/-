package org.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.example.domain.po.Department;

public interface DepartmentService extends IService<Department> {
}
