package org.example.service;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import org.example.domain.dto.*;
import org.example.domain.po.WorkOrder;

import java.util.List;

public interface WorkOrderService extends IService<WorkOrder> {

    void save(WorkOrderDTO workOrderDTO);

    void update(WorkOrderDTO workOrderDTO);

    Page<WorkOrder> queryPage(PageQueryDTO pageQueryDTO);

    void fenpai(FenpaiDTO fenpaiDTO);

    List<DailyOrderStatsDTO> getDailyOrderStatsForJuly();

    List<DeptOrderStatsDTO> getDeptOrderStatsForJuly();
}
