package com.sky.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sky.dto.EmployeeDTO;
import com.sky.dto.EmployeeLoginDTO;
import com.sky.dto.EmployeePageQueryDTO;
import com.sky.entity.Employee;

public interface EmployeeService extends IService<Employee> {

    /**
     * 员工登录
     * @param employeeLoginDTO
     * @return
     */
    Employee login(EmployeeLoginDTO employeeLoginDTO);

    /**
     * 员工分页查询
     * @param employeePageQueryDTO
     * @return
     */
    Page<Employee> queryEmployeePage(EmployeePageQueryDTO employeePageQueryDTO);

    /**
     * 修改员工登录状态
     * @param status
     * @param id
     */
    void updateStatus(Integer status, Long id);

    /**
     * 修改员工数据
     * @param employeeDTO
     */
    void update(EmployeeDTO employeeDTO);


    //void save(EmployeeDTO employeeDTO);
}
