package com.sky.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sky.entity.DishFlavor;

public interface DishFlavorService extends IService<DishFlavor> {
}
