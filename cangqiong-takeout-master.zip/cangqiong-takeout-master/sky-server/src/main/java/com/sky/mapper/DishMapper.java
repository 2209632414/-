package com.sky.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.pagehelper.Page;
import com.sky.dto.DishPageQueryDTO;
import com.sky.entity.Dish;
import com.sky.vo.DishVO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DishMapper extends BaseMapper<Dish> {

    /**
     * 使用pageHelper进行分页
     * @param dishPageQueryDTO
     * @return
     */
    Page<DishVO> pageQuerys(DishPageQueryDTO dishPageQueryDTO);


    /**
     * 根据分类id查询菜品数量
     * @param categoryId
     * @return
     */
    /*@Select("select count(id) from dish where category_id = #{categoryId}")
    Integer countByCategoryId(Long categoryId);*/

}
