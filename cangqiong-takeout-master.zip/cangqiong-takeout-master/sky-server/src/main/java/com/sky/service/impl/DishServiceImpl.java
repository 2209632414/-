package com.sky.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.Db;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.sky.constant.MessageConstant;
import com.sky.constant.StatusConstant;
import com.sky.context.BaseContext;
import com.sky.dto.DishDTO;
import com.sky.dto.DishPageQueryDTO;
import com.sky.entity.Dish;
import com.sky.entity.DishFlavor;
import com.sky.entity.Setmeal;
import com.sky.entity.SetmealDish;
import com.sky.exception.DeletionNotAllowedException;
import com.sky.mapper.DishMapper;
import com.sky.result.PageResult;
import com.sky.service.DishService;
import com.sky.vo.DishVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DishServiceImpl extends ServiceImpl<DishMapper, Dish> implements DishService {

    @Autowired
    private DishMapper dishMapper;

    /**
     * 添加菜品，并添加对应的口味
     *
     * @param dishDTO
     */
    @Override
    @Transactional
    public void saveWithFlavor(DishDTO dishDTO) {
        //拷贝属性
        Dish dish = new Dish();
        BeanUtils.copyProperties(dishDTO, dish);
        //设置对应的属性
        dish.setCreateTime(LocalDateTime.now());
        dish.setUpdateTime(LocalDateTime.now());
        dish.setCreateUser(BaseContext.getCurrentId());
        dish.setUpdateUser(BaseContext.getCurrentId());

        //新增菜品，并返回当前添加菜品的id
        dishMapper.insert(dish);
        Long dishId = dish.getId();
        //新增当前菜品对应的口味，菜品口味是一个List数组
        List<DishFlavor> flavors = dishDTO.getFlavors();
        if (!flavors.isEmpty() && flavors.size() > 0) {
            flavors.forEach(dishFlavor -> {
                dishFlavor.setDishId(dishId);
            });
            //向口味表重插入n条数据
            Db.saveBatch(flavors);
        }
    }

    /**
     * 实现菜品的分页查询
     *
     * @param dishPageQueryDTO
     * @return
     */
    @Override
    public PageResult pageQuerys(DishPageQueryDTO dishPageQueryDTO) {
        // TODO 此处使用的是pageHelper，以后修改为mybatisPlus实现分页
        PageHelper.startPage(dishPageQueryDTO.getPage(), dishPageQueryDTO.getPageSize());
        Page<DishVO> page = dishMapper.pageQuerys(dishPageQueryDTO);
        return new PageResult(page.getTotal(), page.getResult());
    }

    /**
     * 菜品批量删除
     *
     * @param ids
     */
    @Override
    @Transactional
    public void deleteBatch(List<Long> ids) {
        //判断菜品是否为启售的状态
        List<Dish> dishes = dishMapper.selectBatchIds(ids);
        dishes.forEach(dish -> {
            if (dish.getStatus() == StatusConstant.ENABLE) {
                //如果是起售中，抛出业务异常
                throw new DeletionNotAllowedException(MessageConstant.DISH_ON_SALE);
            }
        });


        //判断当前删除的菜品是否被套餐关联
        List<SetmealDish> setmealDishes = Db.lambdaQuery(SetmealDish.class).in(SetmealDish::getDishId, ids).list();
        if (!setmealDishes.isEmpty() && setmealDishes.size() > 0) {
            //如果关联了，抛出业务异常
            throw new DeletionNotAllowedException(MessageConstant.DISH_BE_RELATED_BY_SETMEAL);
        }

        /*//判断当前要删除的菜品是否被套餐关联了
        List<Long> setmealIds = setmealDishMapper.getSetmealIdsByDishIds(ids);
        if(setmealIds != null && setmealIds.size() > 0){
            //如果关联了，抛出业务异常
            throw new DeletionNotAllowedException(MessageConstant.DISH_BE_RELATED_BY_SETMEAL);
        }*/


        //删除当前菜品，同时删除对应的口味
        //1.删除菜品
        dishMapper.deleteBatchIds(ids);
        //2.删除菜品对应的口味
        Db.removeByIds(ids, DishFlavor.class);
    }

    /**
     * 根据id查询菜品相关信息
     *
     * @param id
     * @return
     */
    @Override
    public DishVO getByIdWithFlavor(Long id) {
        //1.获取菜品信息
        Dish dish = dishMapper.selectById(id);
        //1.1.获取菜品的口味信息
        List<DishFlavor> dishFlavors = Db.lambdaQuery(DishFlavor.class)
                .eq(id != null, DishFlavor::getDishId, id).list();
        //2.拷贝属性
        DishVO dishVO = new DishVO();
        BeanUtils.copyProperties(dish, dishVO);
        dishVO.setFlavors(dishFlavors);
        return dishVO;
    }

    /**
     * 修改菜品相关信息
     *
     * @param dishDTO
     */
    @Override
    public void updateWithFlavor(DishDTO dishDTO) {
        //更改菜品表
        lambdaUpdate()
                .set(dishDTO.getName() != null, Dish::getName, dishDTO.getName())
                .set(dishDTO.getCategoryId() != null, Dish::getCategoryId, dishDTO.getCategoryId())
                .set(dishDTO.getPrice() != null, Dish::getPrice, dishDTO.getPrice())
                .set(dishDTO.getImage() != null, Dish::getImage, dishDTO.getImage())
                .set(dishDTO.getDescription() != null, Dish::getDescription, dishDTO.getDescription())
                .set(Dish::getUpdateTime, LocalDateTime.now())
                .set(Dish::getUpdateUser, BaseContext.getCurrentId())
                .eq(Dish::getId, dishDTO.getId())
                .update();
        //更改菜品的口味
        //1.先删除对应的口味
        Db.remove(Wrappers.lambdaQuery(DishFlavor.class).eq(DishFlavor::getDishId, dishDTO.getId()));
        //2.添加更改后的口味
        List<DishFlavor> flavors = dishDTO.getFlavors().stream()
                .map(dishFlavor -> {
                    dishFlavor.setDishId(dishDTO.getId());
                    return dishFlavor;
                })
                .collect(Collectors.toList());
        Db.saveBatch(flavors);
    }

    /**
     * 根据categoryId查询菜品
     * @param categoryId
     * @return
     */
    @Override
    public List<Dish> getByCategoryId(Long categoryId) {
        List<Dish> list = lambdaQuery().eq(Dish::getCategoryId, categoryId).eq(Dish::getStatus,StatusConstant.ENABLE).list();
        return list;
    }

    /**
     * 菜品状态操作
     * @param status
     * @param id
     */
    @Override
    public void startOrStop(Integer status, Long id) {
        //修改状态
        lambdaUpdate().set(Dish::getStatus,status).eq(Dish::getId,id).update();
        //判断status是起售还是停售
        if (status == StatusConstant.DISABLE){
            // 如果是停售操作，还需要将包含当前菜品的套餐也停售
            //1.获取套餐表中菜品对应的套餐的全部id
            List<SetmealDish> setmealDishes = Db.list(Wrappers.lambdaQuery(SetmealDish.class).eq(SetmealDish::getDishId, id));
            List<Long> setmealDishesIds = setmealDishes.stream().map(SetmealDish::getSetmealId).collect(Collectors.toList());
            //1.2将套餐停售
            Db.lambdaUpdate(Setmeal.class).set(Setmeal::getStatus,StatusConstant.DISABLE).in(Setmeal::getId,setmealDishesIds).update();
        }
    }

    /**
     * 条件查询菜品和口味
     * @param categoryId
     * @return
     */
    @Override
    public List<DishVO> listWithFlavor(Long categoryId) {
        //根据根据categoryId查询菜品
        List<Dish> dishList = lambdaQuery().eq(Dish::getCategoryId, categoryId).eq(Dish::getStatus,StatusConstant.ENABLE).list();

        List<DishVO> dishVOList = new ArrayList<>();

        for (Dish d : dishList) {
            DishVO dishVO = new DishVO();
            BeanUtils.copyProperties(d,dishVO);
            //根据菜品id查询对应的口味

            List<DishFlavor> dishFlavors = Db.lambdaQuery(DishFlavor.class)
                    .eq(d.getId() != null, DishFlavor::getDishId, d.getId()).list();

            dishVO.setFlavors(dishFlavors);
            dishVOList.add(dishVO);
        }

        return dishVOList;
    }

}
