package com.sky.service.impl;

import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sky.constant.MessageConstant;
import com.sky.constant.StatusConstant;
import com.sky.context.BaseContext;
import com.sky.dto.EmployeeDTO;
import com.sky.dto.EmployeeLoginDTO;
import com.sky.dto.EmployeePageQueryDTO;
import com.sky.entity.Employee;
import com.sky.exception.AccountLockedException;
import com.sky.exception.AccountNotFoundException;
import com.sky.exception.PasswordErrorException;
import com.sky.mapper.EmployeeMapper;
import com.sky.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.time.LocalDateTime;

@Service
public class EmployeeServiceImpl extends ServiceImpl<EmployeeMapper, Employee> implements EmployeeService {

    @Autowired
    private EmployeeMapper employeeMapper;

    /**
     * 员工登录
     *
     * @param employeeLoginDTO
     * @return
     */
    public Employee login(EmployeeLoginDTO employeeLoginDTO) {
        String username = employeeLoginDTO.getUsername();
        String password = employeeLoginDTO.getPassword();

        //1、根据用户名查询数据库中的数据
        Employee employee = employeeMapper.getByUsername(username);

        //2、处理各种异常情况（用户名不存在、密码不对、账号被锁定）
        if (employee == null) {
            //账号不存在
            throw new AccountNotFoundException(MessageConstant.ACCOUNT_NOT_FOUND);
        }

        //密码比对
        // TODO 后期需要进行md5加密，然后再进行比对
        //进行md5加密,然后进行比对
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        if (!password.equals(employee.getPassword())) {
            //密码错误
            throw new PasswordErrorException(MessageConstant.PASSWORD_ERROR);
        }

        if (employee.getStatus() == StatusConstant.DISABLE) {
            //账号被锁定
            throw new AccountLockedException(MessageConstant.ACCOUNT_LOCKED);
        }

        //3、返回实体对象
        return employee;
    }

    /**
     * 员工分页查询
     * @param employeePageQueryDTO
     * @return
     */
    @Override
    public Page<Employee> queryEmployeePage(EmployeePageQueryDTO employeePageQueryDTO) {
        //获取前端传入的分页条件
        Page<Employee> page = Page.of(employeePageQueryDTO.getPage(), employeePageQueryDTO.getPageSize());
        //排序条件
        page.addOrder(new OrderItem("update_time", true));
        //构建查询条件,根据用户名进行模糊查询
        return lambdaQuery()
                .like(employeePageQueryDTO.getName() != null, Employee::getName, employeePageQueryDTO.getName())
                .page(page);
    }

    /**
     * 修改员工状态
     * @param status
     * @param id
     */
    @Override
    public void updateStatus(Integer status, Long id) {
        lambdaUpdate()
                .set(Employee::getStatus,status)
                .eq(Employee::getId,id)
                .update();
    }

    /**
     * 修改员工信息
     * @param employeeDTO
     */
    @Override
    public void update(EmployeeDTO employeeDTO) {
        //Employee employee = new Employee();
        //使用 hutool 工具拷贝属性
        //BeanUtil.copyProperties(employeeDTO,employee);
        //修改时间和修改人
        //employee.setUpdateTime(LocalDateTime.now());
        //employee.setUpdateUser(BaseContext.getCurrentId());
        lambdaUpdate()
                .set(employeeDTO.getName()!=null, Employee::getName,employeeDTO.getName())
                .set(employeeDTO.getUsername()!=null, Employee::getUsername,employeeDTO.getUsername())
                .set(employeeDTO.getPhone()!=null, Employee::getPhone,employeeDTO.getPhone())
                .set(employeeDTO.getSex()!=null, Employee::getSex,employeeDTO.getSex())
                .set(employeeDTO.getIdNumber()!=null, Employee::getIdNumber,employeeDTO.getIdNumber())
                .set( Employee::getUpdateTime, LocalDateTime.now())
                .set( Employee::getUpdateUser, BaseContext.getCurrentId())
                .eq(Employee::getId,employeeDTO.getId())
                .update();
    }



    /**
     * 新增员工
     *
     * @param employeeDTO
     * @return
     */
   /* @Override
    public void save(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        //对象属性拷贝
        BeanUtils.copyProperties(employeeDTO,employee);

        //设置账号的其它属性,DTO中的属性无法满足PO中的需求需要自己设置
        //1.0 设置账号状态，1为正常，0为封锁
        employee.setStatus(StatusConstant.ENABLE);
        //2.0 初始化密码，默认123456
        employee.setPassword(DigestUtils.md5DigestAsHex(PasswordConstant.DEFAULT_PASSWORD.getBytes()));
        //3.0 设置创建时间和修改时间
        employee.setCreateTime(LocalDateTime.now());
        employee.setUpdateTime(LocalDateTime.now());
        //4.0 设置当前记录创始人的id和修改人的id
        //TODO 此时的创始人id和修改人id需要后期改正，此处先赋予默认值
        employee.setCreateUser(10L);
        employee.setUpdateUser(10L);

        employeeMapper.insert(employee);
    }*/

}
