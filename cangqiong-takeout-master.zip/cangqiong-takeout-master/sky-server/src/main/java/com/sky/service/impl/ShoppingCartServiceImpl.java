package com.sky.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.Db;
import com.sky.context.BaseContext;
import com.sky.dto.ShoppingCartDTO;
import com.sky.entity.Dish;
import com.sky.entity.Setmeal;
import com.sky.entity.ShoppingCart;
import com.sky.mapper.ShoppingCartMapper;
import com.sky.service.ShoppingCartService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ShoppingCartServiceImpl extends ServiceImpl<ShoppingCartMapper, ShoppingCart> implements ShoppingCartService {

    @Autowired
    private ShoppingCartMapper shoppingCartMapper;

    /**
     * 添加购物车
     * @param shoppingCartDTO
     */
    @Override
    public void addShoppingCart(ShoppingCartDTO shoppingCartDTO) {
        //获取shoppingDTO中的菜品id或者套餐id，并将目前用户id加入
        ShoppingCart shoppingCart = new ShoppingCart();
        BeanUtils.copyProperties(shoppingCartDTO,shoppingCart);
        //只能查询自己的购物车数据
        shoppingCart.setUserId(BaseContext.getCurrentId());

        //判断当前商品是否在购物车中
        ShoppingCart cart = lambdaQuery()
                .eq(shoppingCart.getUserId() != null, ShoppingCart::getUserId, shoppingCart.getUserId())
                .eq(shoppingCart.getDishId() != null, ShoppingCart::getDishId, shoppingCart.getDishId())
                .eq(shoppingCart.getDishFlavor() != null, ShoppingCart::getDishFlavor, shoppingCart.getDishFlavor())
                .eq(shoppingCart.getSetmealId() != null, ShoppingCart::getSetmealId, shoppingCart.getSetmealId())
                .one();
        //如果在就将数据+1
        if (cart != null){
            int n = cart.getNumber() + 1;
            lambdaUpdate()
                    .eq(ShoppingCart::getUserId,cart.getUserId())
                    .set(ShoppingCart::getNumber,n)
                    .update();
        }else {
            //不存在就将其加入购物车，还需要判断是套餐还是菜品
            if (shoppingCartDTO.getDishId() != null){
                //1.加入的是菜品
                //1.1获取菜品的名称、图片以及价格
                Dish dish = Db.lambdaQuery(Dish.class).eq(Dish::getId, shoppingCartDTO.getDishId()).one();
                shoppingCart.setName(dish.getName());
                shoppingCart.setImage(dish.getImage());
                shoppingCart.setAmount(dish.getPrice());
            } else {
                //添加到购物车的是套餐
                Setmeal setmeal = Db.lambdaQuery(Setmeal.class).eq(Setmeal::getId, shoppingCartDTO.getSetmealId()).one();
                shoppingCart.setName(setmeal.getName());
                shoppingCart.setImage(setmeal.getImage());
                shoppingCart.setAmount(setmeal.getPrice());
            }
            shoppingCart.setNumber(1);
            shoppingCart.setCreateTime(LocalDateTime.now());
            shoppingCartMapper.insert(shoppingCart);
        }
    }

    /**
     * 查看购物车
     * @return
     */
    @Override
    public List<ShoppingCart> showShoppingCart() {
        return lambdaQuery().eq(ShoppingCart::getUserId,BaseContext.getCurrentId()).list();
    }

    /**
     * 清空购物车
     */
    @Override
    public void cleanShoppingCart() {
        lambdaUpdate().eq(ShoppingCart::getUserId,BaseContext.getCurrentId()).remove();
    }

    /**
     * 删除购物车的一件商品
     * @param shoppingCartDTO
     */
    @Override
    public void subShoppingCart(ShoppingCartDTO shoppingCartDTO) {
        ShoppingCart shoppingCart = lambdaQuery()
                .eq(shoppingCartDTO.getDishId() != null, ShoppingCart::getDishId, shoppingCartDTO.getDishId())
                .eq(shoppingCartDTO.getSetmealId() != null, ShoppingCart::getSetmealId, shoppingCartDTO.getSetmealId())
                .eq(ShoppingCart::getUserId, BaseContext.getCurrentId()).one();
        //判断购物车中该件商品是否只有一件，只有一件就删除该商品
        if (shoppingCart.getNumber() == 1){
            lambdaUpdate()
                    .eq(shoppingCartDTO.getDishId() != null, ShoppingCart::getDishId, shoppingCartDTO.getDishId())
                    .eq(shoppingCartDTO.getSetmealId() != null, ShoppingCart::getSetmealId, shoppingCartDTO.getSetmealId())
                    .eq(ShoppingCart::getUserId, BaseContext.getCurrentId()).remove();
        }
        //数量减一
        shoppingCart.setNumber(shoppingCart.getNumber()-1);
        shoppingCartMapper.updateById(shoppingCart);
    }
}
