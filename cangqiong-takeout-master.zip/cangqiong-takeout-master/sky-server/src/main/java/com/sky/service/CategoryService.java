package com.sky.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sky.dto.CategoryDTO;
import com.sky.dto.CategoryPageQueryDTO;
import com.sky.entity.Category;

import java.util.List;

public interface CategoryService extends IService<Category> {

    /**
     * 新增分类
     * @param categoryDTO
     */
    void save(CategoryDTO categoryDTO);

    /**
     * 分页查询菜品分类
     * @param categoryPageQueryDTO
     * @return
     */
    Page<Category> queryCategoryPage(CategoryPageQueryDTO categoryPageQueryDTO);

    /**
     * 检查情况后删除菜品分类
     * @param id
     */
    void removeByIdAndChecked(Long id);

    /**
     * 修改分类
     * @param categoryDTO
     */
    void update(CategoryDTO categoryDTO);

    /**
     * 修改分类状态
     * @param status
     * @param id
     */
    void startOrStop(Integer status, Long id);

    /**
     * 根据类型查询分类
     * @param type
     */
    List<Category> getListByType(Integer type);

}
