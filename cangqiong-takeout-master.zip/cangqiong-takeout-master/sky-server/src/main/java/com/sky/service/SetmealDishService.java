package com.sky.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sky.entity.SetmealDish;

public interface SetmealDishService  extends IService<SetmealDish> {

}
