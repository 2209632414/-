package com.sky.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.Db;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.sky.constant.MessageConstant;
import com.sky.constant.StatusConstant;
import com.sky.context.BaseContext;
import com.sky.dto.SetmealDTO;
import com.sky.dto.SetmealPageQueryDTO;
import com.sky.entity.Category;
import com.sky.entity.Dish;
import com.sky.entity.Setmeal;
import com.sky.entity.SetmealDish;
import com.sky.exception.DeletionNotAllowedException;
import com.sky.mapper.SetmealMapper;
import com.sky.result.PageResult;
import com.sky.service.SetmealService;
import com.sky.vo.DishItemVO;
import com.sky.vo.SetmealVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SetmealServiceImpl extends ServiceImpl<SetmealMapper, Setmeal> implements SetmealService {

    @Autowired
    private SetmealMapper setmealMapper;

    /**
     * 新增套餐
     * @param setmealDTO
     */
    @Override
    @Transactional
    public void saveWithDish(SetmealDTO setmealDTO) {
        //复制属性，向数据库中添加套餐
        Setmeal setmeal = new Setmeal();
        BeanUtils.copyProperties(setmealDTO,setmeal);
        setmeal.setCreateTime(LocalDateTime.now());
        setmeal.setCreateUser(BaseContext.getCurrentId());
        setmeal.setUpdateTime(LocalDateTime.now());
        setmeal.setUpdateUser(BaseContext.getCurrentId());
        setmealMapper.insert(setmeal);
        //获取套餐关系,加入对应的关系表
        List<SetmealDish> setmealDishes = setmealDTO.getSetmealDishes().stream()
                .map(setmealDish -> {
                    setmealDish.setSetmealId(setmeal.getId());
                    return setmealDish;
                }).collect(Collectors.toList());
        Db.saveBatch(setmealDishes);
    }

    /**
     * 分页查询
     * @param setmealPageQueryDTO
     * @return
     */
    @Override
    public PageResult pageQuery(SetmealPageQueryDTO setmealPageQueryDTO) {
        // TODO 使用PageHelper进行复杂分页
        //分页条件
        PageHelper.startPage(setmealPageQueryDTO.getPage(), setmealPageQueryDTO.getPageSize());
        Page<SetmealVO> page = setmealMapper.pageQuery(setmealPageQueryDTO);
        return new PageResult(page.getTotal(),page.getResult());
    }

    /**
     * 根据id获取套餐详情
     * @param id
     * @return
     */
    @Override
    @Transactional
    public SetmealVO getByIdWithCategory(Long id) {
        //获取套餐详情
        Setmeal setmeal = setmealMapper.selectById(id);
        //拷贝属性
        SetmealVO setmealVO = new SetmealVO();
        BeanUtils.copyProperties(setmeal,setmealVO);
        //获取套餐对应的菜品
        List<SetmealDish> list = Db.lambdaQuery(SetmealDish.class).eq(SetmealDish::getSetmealId, id).list();
        setmealVO.setSetmealDishes(list);
        //获取categoryId对应的name
        Category category = Db.getById(setmeal.getCategoryId(), Category.class);
        setmealVO.setCategoryName(category.getName());
        return setmealVO;
    }

    /**
     *修改套餐
     * @param setmealDTO
     */
    @Override
    @Transactional
    public void update(SetmealDTO setmealDTO) {
        //修改菜品表
        lambdaUpdate()
                .set(setmealDTO.getName()!=null,Setmeal::getName,setmealDTO.getName())
                .set(setmealDTO.getPrice()!=null,Setmeal::getPrice,setmealDTO.getPrice())
                .set(setmealDTO.getDescription()!=null,Setmeal::getDescription,setmealDTO.getDescription())
                .set(setmealDTO.getImage()!=null,Setmeal::getImage,setmealDTO.getImage())
                .set(Setmeal::getUpdateTime,LocalDateTime.now())
                .set(Setmeal::getUpdateUser,BaseContext.getCurrentId())
                .set(setmealDTO.getCategoryId()!=null,Setmeal::getCategoryId,setmealDTO.getCategoryId())
                .update();
        //修改之后需要更改套餐关系表
        //1.先删除已有数据
        Db.remove(Wrappers.lambdaQuery(SetmealDish.class).eq(SetmealDish::getSetmealId, setmealDTO.getId()));
        //2.将修改后的数据插入
        List<SetmealDish> setmealDishes = setmealDTO.getSetmealDishes().stream()
                .map(setmealDish -> {
                   setmealDish.setSetmealId(setmealDTO.getId());
                   return setmealDish;
                }).collect(Collectors.toList());
        Db.saveBatch(setmealDishes);
    }

    /**
     * 删除套餐
     * @param ids
     */
    @Override
    @Transactional
    public void deleteBatch(List<Long> ids) {
        //判断传入的数据是否为空
        if (ids.isEmpty()){
            throw new DeletionNotAllowedException(MessageConstant.BLANK_ERROR);
        }
        //起售中的套餐不能删除
        ids.forEach(id -> {
            //1.查询套餐是否为起售状态
            Setmeal setmeal = setmealMapper.selectById(id);
            if (setmeal.getStatus() == StatusConstant.ENABLE){
                //起售中的套餐不能删除
                throw new DeletionNotAllowedException(MessageConstant.SETMEAL_ON_SALE);
            }
        });
        //删除套餐表与其关系表中对应的数据
        setmealMapper.deleteBatchIds(ids);
        Db.remove(Wrappers.lambdaQuery(SetmealDish.class).in(SetmealDish::getSetmealId,ids));
    }

    /**
     * 更改套餐状态
     * @param id
     * @param status
     */
    @Override
    public void startOrStop(Long id, Integer status) {
        //起售套餐时，判断套餐内是否有停售菜品，有停售菜品提示"套餐内包含未启售菜品，无法启售"
        //1.获取套餐中的菜品
        List<SetmealDish> setmealDishes = Db.lambdaQuery(SetmealDish.class).eq(SetmealDish::getSetmealId, id).list();
        //1.1获取菜品的id集合
        List<Long> dishIds = setmealDishes.stream().map(SetmealDish::getDishId).collect(Collectors.toList());
        //1.2根据菜品id获取菜品的状态
        dishIds.forEach(dishId -> {
            Dish dish = Db.getById(dishId, Dish.class);
            //1.3判断菜品的状态
            if (dish.getStatus() == StatusConstant.DISABLE){
                throw new DeletionNotAllowedException(MessageConstant.SETMEAL_ENABLE_FAILED);
            }
        });
        //2.修改套餐状态
        lambdaUpdate()
                .set(Setmeal::getStatus,status)
                .set(Setmeal::getUpdateTime,LocalDateTime.now())
                .set(Setmeal::getUpdateUser,BaseContext.getCurrentId())
                .eq(Setmeal::getId,id).update();
    }

    /**
     * 条件查询
     * @param setmeal
     * @return
     */
    @Override
    public List<Setmeal> list(Setmeal setmeal) {
        return lambdaQuery()
                .like(setmeal.getName()!=null,Setmeal::getName,setmeal.getName())
                .like(setmeal.getCategoryId()!=null,Setmeal::getCategoryId,setmeal.getCategoryId())
                .like(setmeal.getStatus()!=null,Setmeal::getStatus,setmeal.getStatus())
                .list();
    }

    /**
     * 根据id查询菜品选项
     * @param id
     * @return
     */
    @Override
    public List<DishItemVO> getDishItemById(Long id) {
        return setmealMapper.getDishItemBySetmealId(id);
    }
}
